/**
 * Simple HTTP server to provide a dynamic backend for the GrapesJS portfolio site.
 *
 * The server exposes JSON APIs for managing posts, projects and about data as
 * well as a minimal file manager. All data is stored on disk in JSON files
 * within the data directory. Files uploaded through the file manager are
 * persisted under the files directory. Only built‑in Node.js modules are
 * used so that no external dependencies are required.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { parse: parseUrl } = require('url');

// Directory configuration. Data (posts, projects, about) is stored as JSON in
// DATA_DIR. Uploaded files are stored in FILE_ROOT. HTML/CSS assets live
// alongside this server in the project root.
const ROOT_DIR = path.resolve(__dirname, '..');
const DATA_DIR = path.join(__dirname, 'data');
const FILE_ROOT = path.join(__dirname, 'files');

// Ensure data and files directories exist
for (const dir of [DATA_DIR, FILE_ROOT]) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

// Paths to JSON data files. If they don't exist yet they will be created
// lazily with default contents.
const POSTS_FILE = path.join(DATA_DIR, 'posts.json');
const PROJECTS_FILE = path.join(DATA_DIR, 'projects.json');
const ABOUT_FILE = path.join(DATA_DIR, 'about.json');

/**
 * Load JSON data from disk. If the file does not exist or is malformed,
 * return the provided default value instead.
 * @param {string} file
 * @param {*} defaultValue
 */
function loadJson(file, defaultValue) {
  try {
    if (!fs.existsSync(file)) return defaultValue;
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error(`Error loading ${file}:`, err);
    return defaultValue;
  }
}

/**
 * Persist JSON data to disk. Creates the file if it doesn't exist.
 * @param {string} file
 * @param {*} data
 */
function saveJson(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error(`Error saving ${file}:`, err);
  }
}

/**
 * Parse request body as JSON. Returns a promise which resolves with the
 * parsed object or null if parsing fails. Used for POST/PUT requests.
 * @param {http.IncomingMessage} req
 */
function parseJsonBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
    });
    req.on('end', () => {
      try {
        const json = JSON.parse(body || '{}');
        resolve(json);
      } catch (err) {
        resolve(null);
      }
    });
  });
}

/**
 * Send a JSON response with the provided status and payload.
 * @param {http.ServerResponse} res
 * @param {number} status
 * @param {*} payload
 */
function sendJson(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(payload));
}

/**
 * Recursively read a directory and return an array of entries. Each entry
 * includes name, type and size. The path argument must be relative to
 * FILE_ROOT and resolved to prevent directory traversal.
 * @param {string} relPath
 */
function listFiles(relPath) {
  const safePath = path.resolve(FILE_ROOT, '.' + relPath);
  if (!safePath.startsWith(FILE_ROOT)) {
    return { error: 'Invalid path' };
  }
  let items = [];
  try {
    const stat = fs.statSync(safePath);
    if (!stat.isDirectory()) {
      return { error: 'Not a directory' };
    }
    const names = fs.readdirSync(safePath);
    items = names.map((name) => {
      const full = path.join(safePath, name);
      const s = fs.statSync(full);
      return {
        name,
        type: s.isDirectory() ? 'dir' : 'file',
        size: s.isFile() ? s.size : undefined,
      };
    });
    return { path: relPath, items };
  } catch (err) {
    return { error: err.message };
  }
}

/**
 * Ensure a relative file path remains within FILE_ROOT and return its
 * absolute path. Returns null if the path escapes FILE_ROOT.
 * @param {string} relPath
 */
function safeFilePath(relPath) {
  const full = path.resolve(FILE_ROOT, '.' + relPath);
  return full.startsWith(FILE_ROOT) ? full : null;
}

/**
 * Create HTTP server and define routing logic.
 */
const server = http.createServer(async (req, res) => {
  const { pathname, query } = parseUrl(req.url, true);
  // Handle CORS for API requests (so fetch from browser works)
  if (pathname.startsWith('/api/')) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      return res.end();
    }
  }

  // Serve static assets (HTML, CSS, JS, images). Files live in project root
  const staticExtensions = ['.html', '.css', '.js', '.svg', '.png', '.jpg', '.jpeg', '.ico'];
  const ext = path.extname(pathname || '').toLowerCase();
  if (req.method === 'GET' && (pathname === '/' || staticExtensions.includes(ext))) {
    let filePath;
    if (pathname === '/' || pathname === '') {
      filePath = path.join(ROOT_DIR, 'index.html');
    } else {
      // Prevent directory traversal
      filePath = path.join(ROOT_DIR, pathname.replace(/^\/+/, ''));
    }
    try {
      const stat = fs.statSync(filePath);
      if (stat.isFile()) {
        const stream = fs.createReadStream(filePath);
        // Basic content type detection
        const typeMap = {
          '.html': 'text/html',
          '.css': 'text/css',
          '.js': 'application/javascript',
          '.svg': 'image/svg+xml',
          '.png': 'image/png',
          '.jpg': 'image/jpeg',
          '.jpeg': 'image/jpeg',
          '.ico': 'image/x-icon',
        };
        const ct = typeMap[ext] || 'application/octet-stream';
        res.writeHead(200, { 'Content-Type': ct });
        return stream.pipe(res);
      }
    } catch (err) {
      // fall through to 404
    }
  }

  // API: Posts
  if (pathname === '/api/posts' && req.method === 'GET') {
    const posts = loadJson(POSTS_FILE, []);
    return sendJson(res, 200, posts);
  }
  if (pathname === '/api/posts' && req.method === 'POST') {
    const body = await parseJsonBody(req);
    if (!body || !body.title) return sendJson(res, 400, { error: 'Invalid post data' });
    const posts = loadJson(POSTS_FILE, []);
    if (body.id) {
      // Update existing
      const idx = posts.findIndex((p) => p.id === body.id);
      if (idx !== -1) {
        posts[idx] = { ...posts[idx], ...body };
        saveJson(POSTS_FILE, posts);
        return sendJson(res, 200, posts[idx]);
      }
    }
    // Create new
    const newPost = {
      id: Date.now().toString(),
      title: body.title,
      summary: body.summary || '',
      content: body.content || '',
      cover: body.cover || '',
      featured: !!body.featured,
      status: body.status || 'draft',
      date: body.date || new Date().toISOString(),
    };
    posts.unshift(newPost);
    saveJson(POSTS_FILE, posts);
    return sendJson(res, 201, newPost);
  }
  // DELETE /api/posts/:id
  if (pathname.startsWith('/api/posts/') && req.method === 'DELETE') {
    const id = pathname.split('/').pop();
    let posts = loadJson(POSTS_FILE, []);
    const post = posts.find((p) => p.id === id);
    if (!post) return sendJson(res, 404, { error: 'Not found' });
    posts = posts.filter((p) => p.id !== id);
    saveJson(POSTS_FILE, posts);
    return sendJson(res, 200, { message: 'Deleted' });
  }

  // API: Projects
  if (pathname === '/api/projects' && req.method === 'GET') {
    const projects = loadJson(PROJECTS_FILE, []);
    return sendJson(res, 200, projects);
  }
  if (pathname === '/api/projects' && req.method === 'POST') {
    const body = await parseJsonBody(req);
    if (!body || !body.name) return sendJson(res, 400, { error: 'Invalid project data' });
    const projects = loadJson(PROJECTS_FILE, []);
    if (body.id) {
      const idx = projects.findIndex((p) => p.id === body.id);
      if (idx !== -1) {
        projects[idx] = { ...projects[idx], ...body, stars: parseInt(body.stars || projects[idx].stars || 0, 10) };
        saveJson(PROJECTS_FILE, projects);
        return sendJson(res, 200, projects[idx]);
      }
    }
    const newProj = {
      id: Date.now().toString(),
      name: body.name,
      description: body.description || '',
      url: body.url || '',
      stars: parseInt(body.stars || 0, 10),
    };
    projects.push(newProj);
    saveJson(PROJECTS_FILE, projects);
    return sendJson(res, 201, newProj);
  }
  // DELETE /api/projects/:id
  if (pathname.startsWith('/api/projects/') && req.method === 'DELETE') {
    const id = pathname.split('/').pop();
    let projects = loadJson(PROJECTS_FILE, []);
    const proj = projects.find((p) => p.id === id);
    if (!proj) return sendJson(res, 404, { error: 'Not found' });
    projects = projects.filter((p) => p.id !== id);
    saveJson(PROJECTS_FILE, projects);
    return sendJson(res, 200, { message: 'Deleted' });
  }

  // API: About
  if (pathname === '/api/about' && req.method === 'GET') {
    const about = loadJson(ABOUT_FILE, { title: '', content: '' });
    return sendJson(res, 200, about);
  }
  if (pathname === '/api/about' && req.method === 'POST') {
    const body = await parseJsonBody(req);
    if (!body || !body.title) return sendJson(res, 400, { error: 'Invalid about data' });
    const about = { title: body.title, content: body.content || '' };
    saveJson(ABOUT_FILE, about);
    return sendJson(res, 200, about);
  }

  // API: File Manager
  // List directory contents: GET /api/files?path=/path
  if (pathname === '/api/files' && req.method === 'GET') {
    const relPath = decodeURIComponent(query.path || '/');
    const result = listFiles(relPath);
    if (result.error) return sendJson(res, 400, { error: result.error });
    return sendJson(res, 200, result);
  }
  // Make directory: POST /api/files/mkdir { path, name }
  if (pathname === '/api/files/mkdir' && req.method === 'POST') {
    const body = await parseJsonBody(req);
    if (!body || !body.path || !body.name) return sendJson(res, 400, { error: 'Invalid body' });
    const parent = safeFilePath(body.path);
    if (!parent) return sendJson(res, 400, { error: 'Invalid path' });
    const dirPath = path.join(parent, body.name);
    try {
      fs.mkdirSync(dirPath, { recursive: false });
      return sendJson(res, 201, { message: 'Created' });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }
  // Upload file: POST /api/files/upload { path, name, data }
  if (pathname === '/api/files/upload' && req.method === 'POST') {
    const body = await parseJsonBody(req);
    if (!body || !body.path || !body.name || !body.data) {
      return sendJson(res, 400, { error: 'Invalid body' });
    }
    const dir = safeFilePath(body.path);
    if (!dir) return sendJson(res, 400, { error: 'Invalid path' });
    const filePath = path.join(dir, body.name);
    try {
      const buffer = Buffer.from(body.data.split(',').pop(), 'base64');
      fs.writeFileSync(filePath, buffer);
      return sendJson(res, 201, { message: 'Uploaded' });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }
  // Delete file or directory: POST /api/files/delete { path }
  if (pathname === '/api/files/delete' && req.method === 'POST') {
    const body = await parseJsonBody(req);
    if (!body || !body.path) return sendJson(res, 400, { error: 'Invalid body' });
    const target = safeFilePath(body.path);
    if (!target || target === FILE_ROOT) return sendJson(res, 400, { error: 'Invalid path' });
    try {
      const stat = fs.statSync(target);
      if (stat.isDirectory()) {
        fs.rmdirSync(target, { recursive: true });
      } else {
        fs.unlinkSync(target);
      }
      return sendJson(res, 200, { message: 'Deleted' });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }
  // Download file: GET /api/files/download?path=/path/file
  if (pathname === '/api/files/download' && req.method === 'GET') {
    const relPath = decodeURIComponent(query.path || '');
    const fullPath = safeFilePath(relPath);
    if (!fullPath) return sendJson(res, 400, { error: 'Invalid path' });
    try {
      const stat = fs.statSync(fullPath);
      if (!stat.isFile()) return sendJson(res, 400, { error: 'Not a file' });
      const stream = fs.createReadStream(fullPath);
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${path.basename(fullPath)}"`,
      });
      return stream.pipe(res);
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }

  // Fallback 404
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not found');
});

// Start the server on a configurable port. When running locally, set PORT
// environment variable or default to 3000.
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});