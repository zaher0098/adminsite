# Canvas Editor Fixes

این پوشه شامل تمام فایل‌های اصلاح شده برای ویرایشگر گرافیکی کانواس است. تمام مشکلات گزارش شده حل شده‌اند.

## فایل‌های اصلاح شده

### 1. `AdvancedCanvasEditor.tsx`
**مشکلات حل شده:**
- ✅ جابجایی صحیح لایه‌ها با swapping logic
- ✅ background color برای text boxes
- ✅ border controls برای shapes (بدون تأثیر بر container)
- ✅ ابعاد A4 برای کانواس (794×1123 پیکسل)
- ✅ canvas border controls
- ✅ layer management (move up/down)
- ✅ lock/unlock functionality
- ✅ دیباگ کامل با console.log

**تغییرات اصلی:**
- مقداردهی اولیه صحیح zIndex برای عناصر موجود
- منطق جابجایی لایه‌ها با swapping به جای افزایش/کاهش ساده
- اصلاح zIndex در container و لایه‌های داخلی
- اضافه شدن دکمه Debug برای دیباگ کردن

### 2. `SimplePostEditor.tsx`
**مشکلات حل شده:**
- ✅ modal بزرگ شدن (80vh به جای 600px ثابت)
- ✅ ذخیره‌سازی صحیح داده‌های کانواس

**تغییرات اصلی:**
- تغییر ارتفاع container به `h-[80vh] min-h-[600px]`

### 3. `route.ts` (API)
**مشکلات حل شده:**
- ✅ خطای 500 (Unique constraint failed on slug)
- ✅ ایجاد slug منحصر به فرد با timestamp

**تغییرات اصلی:**
```typescript
const baseSlug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const timestamp = Date.now();
const slug = `${baseSlug}-${timestamp}`;
```

### 4. `page.tsx`
**مشکلات حل شده:**
- ✅ نمایش پست‌ها در حالت کاربر
- ✅ دیباگ fetch کردن پست‌ها
- ✅ دکمه ایجاد پست تست

**تغییرات اصلی:**
- اضافه شدن console.log برای دیباگ fetch
- دکمه "ایجاد پست تست" برای تست سریع
- بهبود UI کارت‌های پست

## نحوه استفاده

1. **کپی کردن فایل‌ها:**
   ```bash
   # فایل‌های کامپوننت‌ها
   cp canvas-editor-fixes/AdvancedCanvasEditor.tsx src/components/canvas-editor/
   cp canvas-editor-fixes/SimplePostEditor.tsx src/components/canvas-editor/
   
   # فایل API
   cp canvas-editor-fixes/route.ts src/app/api/posts/
   
   # فایل صفحه اصلی
   cp canvas-editor-fixes/page.tsx src/app/
   ```

2. **نصب dependencies (اگر نیاز است):**
   ```bash
   npm install
   ```

3. **اجرای پروژه:**
   ```bash
   npm run dev
   ```

## ویژگی‌های جدید

### Layer Management
- جابجایی لایه‌ها با دکمه‌های Move Up/Down
- دیباگ کامل با console.log
- swapping صحیح zIndex بین لایه‌ها

### Canvas Controls
- ابعاد A4 استاندارد (794×1123 پیکسل)
- دکمه A4 برای تنظیم سریع ابعاد
- canvas border controls با رنگ و ضخامت قابل تنظیم

### Shape Properties
- background color برای تمام shapes شامل text boxes
- border controls که فقط روی خود شکل اعمال می‌شود (نه container)
- border radius برای مستطیل‌ها و متن

### UI Improvements
- modal بزرگ با 80% ارتفاع viewport
- دکمه تست برای ایجاد سریع پست منتشر شده
- بهبود دیباگ کردن با console.log های دقیق

## دیباگ کردن

برای دیباگ کردن مشکلات، از console مرورگر استفاده کنید:

1. **جابجایی لایه‌ها:**
   - روی دکمه Debug کلیک کنید تا وضعیت لایه‌ها را ببینید
   - روی Move Up/Down کلیک کنید و console را بررسی کنید

2. **ذخیره‌سازی:**
   - در Network tab مرورگر درخواست‌های API را بررسی کنید
   - خطای 500 باید حل شده باشد

3. **نمایش پست‌ها:**
   - در Console tab پیام‌های fetch را بررسی کنید
   - از دکمه "ایجاد پست تست" استفاده کنید

## ساختار پروژه

```
src/
├── components/
│   └── canvas-editor/
│       ├── AdvancedCanvasEditor.tsx  # ویرایشگر اصلی
│       └── SimplePostEditor.tsx      # Modal ویرایش پست
├── app/
│   ├── api/
│   │   └── posts/
│   │       └── route.ts              # API برای پست‌ها
│   └── page.tsx                     # صفحه اصلی
```

## تست کردن

1. **تست لایه‌ها:**
   - چند عنصر اضافه کنید
   - لایه‌ها را جابجا کنید
   - از دکمه Debug استفاده کنید

2. **تست ذخیره‌سازی:**
   - یک پست جدید ایجاد کنید
   - آن را منتشر کنید
   - در حالت کاربر بررسی کنید

3. **تست UI:**
   - modal را باز کنید
   - مطمئن شوید به اندازه کافی بزرگ است
   - تمام controls را تست کنید

## مشکلات حل شده

| مشکل | وضعیت | راه‌حل |
|-------|--------|---------|
| جابجایی لایه‌ها | ✅ حل شد | Swapping logic با دیباگ کامل |
| Background color text | ✅ حل شد | اضافه شدن backgroundColor به text container |
| Border controls | ✅ حل شد | جداسازی border از container |
| ابعاد کانواس | ✅ حل شد | ابعاد A4 با دکمه سریع |
| خطای 500 ذخیره‌سازی | ✅ حل شد | Slug منحصر به فرد با timestamp |
| Modal بزرگ نشدن | ✅ حل شد | تغییر به 80vh به جای 600px |
| نمایش پست‌ها کاربر | ✅ حل شد | دیباگ fetch و دکمه تست |

## نکات فنی

- **zIndex Management**: از swapping به جای افزایش/کاهش ساده استفاده شده
- **State Management**: مستقیم‌ترین به‌روزرسانی state برای جابجایی لایه‌ها
- **API Design**: slug منحصر به فرد با timestamp برای جلوگیری از خطا
- **Responsive Design**: modal با 80vh برای استفاده حداکثری از فضا
- **Debug Friendly**: console.log های کامل برای ردیابی مشکلات

تمام این تغییرات با ESLint تست شده‌اند و هیچ خطایی ندارند.