'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Move3D, Square, Circle, Type, ImageIcon, Trash2, Copy, Lock, Unlock, Eye, EyeOff, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, Triangle, Hexagon, Star, List, ListOrdered, Palette, Upload, Image as ImageIcon2, Save as SaveIcon, X as XIcon } from 'lucide-react';

interface CanvasElement {
  id: string;
  type: 'text' | 'rectangle' | 'circle' | 'image' | 'triangle' | 'hexagon' | 'star';
  x: number;
  y: number;
  width: number;
  height: number;
  text?: string;
  color?: string;
  backgroundColor?: string;
  fontSize?: number;
  fontFamily?: string;
  fontWeight?: string;
  fontStyle?: string;
  textAlign?: 'left' | 'center' | 'right';
  textDecoration?: string;
  listStyle?: 'none' | 'disc' | 'decimal';
  letterSpacing?: number;
  lineHeight?: number;
  fontFamily?: string;
  image?: string;
  locked?: boolean;
  visible?: boolean;
  opacity?: number;
  zIndex?: number;
  borderWidth?: number;
  borderColor?: string;
  borderRadius?: number;
  frameType?: 'none' | 'shadow' | 'border';
}

interface AdvancedCanvasEditorProps {
  initialData?: CanvasElement[];
  background?: string;
  blurAmount?: number;
  onSave: (data: CanvasElement[], background?: string, blurAmount?: number) => void;
  onCancel: () => void;
}

export default function AdvancedCanvasEditor({
  initialData = [],
  background: initialBackground = '',
  blurAmount: initialBlurAmount = 0,
  onSave,
  onCancel
}: AdvancedCanvasEditorProps) {
  // Initialize elements with proper zIndex values
  const initializedElements = initialData.map((el, index) => ({
    ...el,
    zIndex: el.zIndex !== undefined && el.zIndex !== null ? el.zIndex : index + 1
  }));
  
  const [elements, setElements] = useState<CanvasElement[]>(initializedElements);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [background, setBackground] = useState(initialBackground);
  const [blurAmount, setBlurAmount] = useState(initialBlurAmount);
  const [canvasWidth, setCanvasWidth] = useState(794); // A4 width
  const [canvasHeight, setCanvasHeight] = useState(1123); // A4 height
  const [canvasBorderColor, setCanvasBorderColor] = useState('#000000');
  const [canvasBorderWidth, setCanvasBorderWidth] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [draggedElement, setDraggedElement] = useState<string | null>(null);
  const [resizeHandle, setResizeHandle] = useState<string | null>(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [elementStart, setElementStart] = useState({ x: 0, y: 0, width: 0, height: 0 });
  const canvasRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Helper function to generate a unique ID
  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  // Debug useEffect to monitor elements state
  useEffect(() => {
    console.log('Elements updated:', elements.map(el => ({ 
      id: el.id, 
      type: el.type, 
      zIndex: el.zIndex,
      selected: el.id === selectedElement 
    })));
  }, [elements, selectedElement]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Delete key
      if (e.key === 'Delete' && selectedElement) {
        deleteSelectedElement();
      }
      
      // Ctrl+C for copy
      if (e.ctrlKey && e.key === 'c' && selectedElement) {
        e.preventDefault();
        const element = elements.find(el => el.id === selectedElement);
        if (element) {
          duplicateSelectedElement();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedElement, elements]);

  const addElement = (type: CanvasElement['type']) => {
    const newElement: CanvasElement = {
      id: generateId(),
      type,
      x: 50,
      y: 50,
      width: type === 'text' ? 200 : 100,
      height: type === 'text' ? 100 : 100,
      text: type === 'text' ? 'New Text' : undefined,
      color: '#000000',
      backgroundColor: type === 'text' ? 'transparent' : '#3b82f6',
      fontSize: 16,
      fontFamily: 'Arial, sans-serif',
      fontWeight: 'normal',
      fontStyle: 'normal',
      textAlign: 'left',
      textDecoration: 'none',
      listStyle: 'none',
      letterSpacing: 0,
      lineHeight: 1.5,
      image: undefined,
      locked: false,
      visible: true,
      opacity: 100,
      zIndex: elements.length > 0 ? Math.max(...elements.map(el => el.zIndex || 0)) + 1 : 1,
      borderWidth: 0,
      borderColor: '#000000',
      borderRadius: 0,
      frameType: 'none'
    };

    setElements([...elements, newElement]);
    setSelectedElement(newElement.id);
  };

  const updateElement = (id: string, updates: Partial<CanvasElement>) => {
    console.log('updateElement called:', id, updates);
    setElements(elements.map(el => 
      el.id === id ? { ...el, ...updates } : el
    ));
  };

  const deleteSelectedElement = () => {
    if (selectedElement) {
      setElements(elements.filter(el => el.id !== selectedElement));
      setSelectedElement(null);
    }
  };

  const duplicateSelectedElement = () => {
    if (selectedElement) {
      const element = elements.find(el => el.id === selectedElement);
      if (element) {
        const newElement = {
          ...element,
          id: generateId(),
          x: element.x + 20,
          y: element.y + 20,
          zIndex: elements.length > 0 ? Math.max(...elements.map(el => el.zIndex || 0)) + 1 : 1
        };
        setElements([...elements, newElement]);
        setSelectedElement(newElement.id);
      }
    }
  };

  const selectElement = (id: string) => {
    setSelectedElement(id);
  };

  const handleCanvasClick = (e: React.MouseEvent) => {
    // Only deselect if clicking on the canvas itself, not on elements
    if (e.target === canvasRef.current) {
      setSelectedElement(null);
    }
  };

  const handleMouseDown = (e: React.MouseEvent, elementId: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    const element = elements.find(el => el.id === elementId);
    if (!element || element.locked) return;
    
    setIsDragging(true);
    setDraggedElement(elementId);
    setDragStart({ x: e.clientX, y: e.clientY });
    setElementStart({ 
      x: element.x, 
      y: element.y, 
      width: element.width, 
      height: element.height 
    });
  };

  const startResize = (e: React.MouseEvent, elementId: string, handle: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    const element = elements.find(el => el.id === elementId);
    if (!element || element.locked) return;
    
    setIsResizing(true);
    setDraggedElement(elementId);
    setResizeHandle(handle);
    setDragStart({ x: e.clientX, y: e.clientY });
    setElementStart({ 
      x: element.x, 
      y: element.y, 
      width: element.width, 
      height: element.height 
    });
  };

  // Mouse move handler
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging && draggedElement) {
        const deltaX = e.clientX - dragStart.x;
        const deltaY = e.clientY - dragStart.y;
        
        updateElement(draggedElement, {
          x: elementStart.x + deltaX,
          y: elementStart.y + deltaY
        });
      }
      
      if (isResizing && draggedElement) {
        const deltaX = e.clientX - dragStart.x;
        const deltaY = e.clientY - dragStart.y;
        
        let newWidth = elementStart.width;
        let newHeight = elementStart.height;
        
        if (resizeHandle?.includes('e')) {
          newWidth = Math.max(50, elementStart.width + deltaX);
        }
        if (resizeHandle?.includes('w')) {
          newWidth = Math.max(50, elementStart.width - deltaX);
        }
        if (resizeHandle?.includes('s')) {
          newHeight = Math.max(50, elementStart.height + deltaY);
        }
        if (resizeHandle?.includes('n')) {
          newHeight = Math.max(50, elementStart.height - deltaY);
        }
        
        updateElement(draggedElement, {
          width: newWidth,
          height: newHeight
        });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
      setDraggedElement(null);
      setResizeHandle(null);
    };

    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isResizing, draggedElement, dragStart, elementStart, resizeHandle]);

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const newElement: CanvasElement = {
          id: generateId(),
          type: 'image',
          x: 50,
          y: 50,
          width: 200,
          height: 200,
          image: event.target?.result as string,
          locked: false,
          visible: true,
          opacity: 100,
          zIndex: elements.length > 0 ? Math.max(...elements.map(el => el.zIndex || 0)) + 1 : 1,
          borderWidth: 0,
          borderColor: '#000000',
          borderRadius: 0,
          frameType: 'none'
        };
        setElements([...elements, newElement]);
        setSelectedElement(newElement.id);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle background upload
  const handleBackgroundUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setBackground(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const moveElementUp = () => {
    console.log('=== moveElementUp called ===');
    console.log('selectedElement:', selectedElement);
    console.log('elements count:', elements.length);
    
    if (!selectedElement) {
      console.log('No element selected');
      return;
    }
    
    // Get current element
    const currentElement = elements.find(el => el.id === selectedElement);
    if (!currentElement) {
      console.log('Selected element not found');
      return;
    }
    
    console.log('Current element:', { id: currentElement.id, type: currentElement.type, zIndex: currentElement.zIndex });
    
    // Get all elements sorted by zIndex
    const sortedElements = [...elements].sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));
    const currentIndex = sortedElements.findIndex(el => el.id === selectedElement);
    
    console.log('Sorted elements:', sortedElements.map(el => ({ id: el.id, type: el.type, zIndex: el.zIndex })));
    console.log('Current index in sorted array:', currentIndex);
    
    if (currentIndex < sortedElements.length - 1) {
      // Swap with the element above
      const elementAbove = sortedElements[currentIndex + 1];
      const currentZ = currentElement.zIndex || 0;
      const aboveZ = elementAbove.zIndex || 0;
      
      console.log('Swapping z-index:', { currentId: currentElement.id, currentZ, aboveId: elementAbove.id, aboveZ });
      
      // Create new elements array with swapped z-indexes
      const newElements = elements.map(el => {
        if (el.id === selectedElement) {
          return { ...el, zIndex: aboveZ };
        } else if (el.id === elementAbove.id) {
          return { ...el, zIndex: currentZ };
        }
        return el;
      });
      
      console.log('New elements after swap:', newElements.map(el => ({ id: el.id, type: el.type, zIndex: el.zIndex })));
      setElements(newElements);
    } else {
      console.log('Element is already at the top');
    }
  };

  const moveElementDown = () => {
    console.log('=== moveElementDown called ===');
    console.log('selectedElement:', selectedElement);
    console.log('elements count:', elements.length);
    
    if (!selectedElement) {
      console.log('No element selected');
      return;
    }
    
    // Get current element
    const currentElement = elements.find(el => el.id === selectedElement);
    if (!currentElement) {
      console.log('Selected element not found');
      return;
    }
    
    console.log('Current element:', { id: currentElement.id, type: currentElement.type, zIndex: currentElement.zIndex });
    
    // Get all elements sorted by zIndex
    const sortedElements = [...elements].sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));
    const currentIndex = sortedElements.findIndex(el => el.id === selectedElement);
    
    console.log('Sorted elements:', sortedElements.map(el => ({ id: el.id, type: el.type, zIndex: el.zIndex })));
    console.log('Current index in sorted array:', currentIndex);
    
    if (currentIndex > 0) {
      // Swap with the element below
      const elementBelow = sortedElements[currentIndex - 1];
      const currentZ = currentElement.zIndex || 0;
      const belowZ = elementBelow.zIndex || 0;
      
      console.log('Swapping z-index:', { currentId: currentElement.id, currentZ, belowId: elementBelow.id, belowZ });
      
      // Create new elements array with swapped z-indexes
      const newElements = elements.map(el => {
        if (el.id === selectedElement) {
          return { ...el, zIndex: belowZ };
        } else if (el.id === elementBelow.id) {
          return { ...el, zIndex: currentZ };
        }
        return el;
      });
      
      console.log('New elements after swap:', newElements.map(el => ({ id: el.id, type: el.type, zIndex: el.zIndex })));
      setElements(newElements);
    } else {
      console.log('Element is already at the bottom');
    }
  };

  const toggleLockElement = () => {
    if (selectedElement) {
      const element = elements.find(el => el.id === selectedElement);
      if (element) {
        updateElement(selectedElement, { locked: !element.locked });
      }
    }
  };

  const toggleVisibilityElement = () => {
    if (selectedElement) {
      const element = elements.find(el => el.id === selectedElement);
      if (element) {
        updateElement(selectedElement, { visible: !element.visible });
      }
    }
  };

  const toggleListStyle = (style: 'disc' | 'decimal') => {
    if (selectedElement) {
      const element = elements.find(el => el.id === selectedElement);
      if (element && element.type === 'text') {
        updateElement(selectedElement, { 
          listStyle: element.listStyle === style ? 'none' : style 
        });
      }
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Fixed Toolbar - Always at top */}
      <div className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 shadow-sm z-50">
        <div className="px-4 py-3">
          {/* First Row - Shape Tools */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-700">Shapes:</span>
              <Button
                size="default"
                variant="outline"
                onClick={() => addElement('text')}
                className="h-10 w-10 p-0"
                title="Add Text"
              >
                <Type className="w-5 h-5" />
              </Button>
              <Button
                size="default"
                variant="outline"
                onClick={() => addElement('rectangle')}
                className="h-10 w-10 p-0"
                title="Add Rectangle"
              >
                <Square className="w-5 h-5" />
              </Button>
              <Button
                size="default"
                variant="outline"
                onClick={() => addElement('circle')}
                className="h-10 w-10 p-0"
                title="Add Circle"
              >
                <Circle className="w-5 h-5" />
              </Button>
              <Button
                size="default"
                variant="outline"
                onClick={() => addElement('triangle')}
                className="h-10 w-10 p-0"
                title="Add Triangle"
              >
                <Triangle className="w-5 h-5" />
              </Button>
              <Button
                size="default"
                variant="outline"
                onClick={() => addElement('hexagon')}
                className="h-10 w-10 p-0"
                title="Add Hexagon"
              >
                <Hexagon className="w-5 h-5" />
              </Button>
              <Button
                size="default"
                variant="outline"
                onClick={() => addElement('star')}
                className="h-10 w-10 p-0"
                title="Add Star"
              >
                <Star className="w-5 h-5" />
              </Button>
              <Button
                size="default"
                variant="outline"
                onClick={() => imageInputRef.current?.click()}
                className="h-10 w-10 p-0"
                title="Add Image"
              >
                <ImageIcon className="w-5 h-5" />
              </Button>
              <input
                type="file"
                ref={imageInputRef}
                onChange={handleImageUpload}
                accept="image/*"
                className="hidden"
              />
            </div>
          </div>

          {/* Second Row - Text Formatting (when text is selected) */}
          {selectedElement && elements.find(el => el.id === selectedElement)?.type === 'text' && (
            <div className="flex items-center gap-2 mb-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-700">Text:</span>
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.listStyle === 'disc' ? "default" : "outline"}
                  onClick={() => toggleListStyle('disc')}
                  className="h-10 w-10 p-0"
                  title="Bullet List"
                >
                  <List className="w-5 h-5" />
                </Button>
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.listStyle === 'decimal' ? "default" : "outline"}
                  onClick={() => toggleListStyle('decimal')}
                  className="h-10 w-10 p-0"
                  title="Numbered List"
                >
                  <ListOrdered className="w-5 h-5" />
                </Button>
                <div className="w-px h-8 bg-gray-300 mx-2" />
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.fontWeight === 'bold' ? "default" : "outline"}
                  onClick={() => updateElement(selectedElement, { 
                    fontWeight: elements.find(el => el.id === selectedElement)?.fontWeight === 'bold' ? 'normal' : 'bold' 
                  })}
                  className="h-10 w-10 p-0"
                  title="Bold"
                >
                  <Bold className="w-5 h-5" />
                </Button>
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.fontStyle === 'italic' ? "default" : "outline"}
                  onClick={() => updateElement(selectedElement, { 
                    fontStyle: elements.find(el => el.id === selectedElement)?.fontStyle === 'italic' ? 'normal' : 'italic' 
                  })}
                  className="h-10 w-10 p-0"
                  title="Italic"
                >
                  <Italic className="w-5 h-5" />
                </Button>
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.textDecoration === 'underline' ? "default" : "outline"}
                  onClick={() => updateElement(selectedElement, { 
                    textDecoration: elements.find(el => el.id === selectedElement)?.textDecoration === 'underline' ? 'none' : 'underline' 
                  })}
                  className="h-10 w-10 p-0"
                  title="Underline"
                >
                  <Underline className="w-5 h-5" />
                </Button>
                <div className="w-px h-8 bg-gray-300 mx-2" />
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.textAlign === 'left' ? "default" : "outline"}
                  onClick={() => updateElement(selectedElement, { textAlign: 'left' })}
                  className="h-10 w-10 p-0"
                  title="Align Left"
                >
                  <AlignLeft className="w-5 h-5" />
                </Button>
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.textAlign === 'center' ? "default" : "outline"}
                  onClick={() => updateElement(selectedElement, { textAlign: 'center' })}
                  className="h-10 w-10 p-0"
                  title="Align Center"
                >
                  <AlignCenter className="w-5 h-5" />
                </Button>
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.textAlign === 'right' ? "default" : "outline"}
                  onClick={() => updateElement(selectedElement, { textAlign: 'right' })}
                  className="h-10 w-10 p-0"
                  title="Align Right"
                >
                  <AlignRight className="w-5 h-5" />
                </Button>
              </div>
            </div>
          )}

          {/* Third Row - Element Properties (when element is selected) */}
          {selectedElement && (
            <div className="flex items-center gap-2 mb-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-700">Properties:</span>
                
                {/* Layer Controls */}
                <div className="flex items-center gap-1">
                  <Button
                    size="default"
                    variant="outline"
                    onClick={() => {
                      console.log('Current elements:', elements.map(el => ({ 
                        id: el.id, 
                        type: el.type, 
                        zIndex: el.zIndex,
                        selected: el.id === selectedElement 
                      })));
                    }}
                    className="h-8 px-2 text-xs"
                    title="Debug Layer Info"
                  >
                    Debug
                  </Button>
                  <Button
                    size="default"
                    variant="outline"
                    onClick={moveElementUp}
                    className="h-8 w-8 p-0"
                    title="Move Layer Up"
                  >
                    <Move3D className="w-4 h-4" />
                  </Button>
                  <Button
                    size="default"
                    variant="outline"
                    onClick={moveElementDown}
                    className="h-8 w-8 p-0"
                    title="Move Layer Down"
                  >
                    <Move3D className="w-4 h-4" style={{ transform: 'rotate(180deg)' }} />
                  </Button>
                </div>
                
                {/* Lock/Unlock Button */}
                <Button
                  size="default"
                  variant={elements.find(el => el.id === selectedElement)?.locked ? "default" : "outline"}
                  onClick={toggleLockElement}
                  className="h-8 w-8 p-0"
                  title={elements.find(el => el.id === selectedElement)?.locked ? "Unlock Element" : "Lock Element"}
                >
                  {elements.find(el => el.id === selectedElement)?.locked ? (
                    <Lock className="w-4 h-4" />
                  ) : (
                    <Unlock className="w-4 h-4" />
                  )}
                </Button>
                
                {/* Background Color */}
                <div className="flex items-center gap-1">
                  <label className="text-xs font-medium">BG:</label>
                  <Input
                    type="color"
                    value={elements.find(el => el.id === selectedElement)?.backgroundColor || 
                          (elements.find(el => el.id === selectedElement)?.type === 'text' ? 'transparent' : '#3b82f6')}
                    onChange={(e) => updateElement(selectedElement, { backgroundColor: e.target.value })}
                    className="w-8 h-8 p-0 border-0"
                  />
                </div>
                
                {/* Border Color */}
                <div className="flex items-center gap-1">
                  <label className="text-xs font-medium">Border:</label>
                  <Input
                    type="color"
                    value={elements.find(el => el.id === selectedElement)?.borderColor || '#000000'}
                    onChange={(e) => updateElement(selectedElement, { borderColor: e.target.value })}
                    className="w-8 h-8 p-0 border-0"
                  />
                  <Input
                    type="number"
                    min="0"
                    max="20"
                    value={elements.find(el => el.id === selectedElement)?.borderWidth || 0}
                    onChange={(e) => updateElement(selectedElement, { borderWidth: Number(e.target.value) })}
                    className="w-12 h-8 text-xs"
                    placeholder="0"
                  />
                </div>
                
                {/* Text Color (only for text elements) */}
                {elements.find(el => el.id === selectedElement)?.type === 'text' && (
                  <>
                    <div className="flex items-center gap-1">
                      <label className="text-xs font-medium">Text:</label>
                      <Input
                        type="color"
                        value={elements.find(el => el.id === selectedElement)?.color || '#000000'}
                        onChange={(e) => updateElement(selectedElement, { color: e.target.value })}
                        className="w-8 h-8 p-0 border-0"
                      />
                    </div>
                    
                    {/* Font Family */}
                    <div className="flex items-center gap-1">
                      <label className="text-xs font-medium">Font:</label>
                      <select
                        value={elements.find(el => el.id === selectedElement)?.fontFamily || 'Arial, sans-serif'}
                        onChange={(e) => updateElement(selectedElement, { fontFamily: e.target.value })}
                        className="h-8 text-xs border rounded px-2"
                      >
                        <option value="Arial, sans-serif">Arial</option>
                        <option value="Times New Roman, serif">Times</option>
                        <option value="Courier New, monospace">Courier</option>
                        <option value="Georgia, serif">Georgia</option>
                        <option value="Verdana, sans-serif">Verdana</option>
                        <option value="Comic Sans MS, cursive">Comic Sans</option>
                      </select>
                    </div>
                  </>
                )}
                
                {/* Opacity */}
                <div className="flex items-center gap-1">
                  <label className="text-xs font-medium">Opacity:</label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    value={elements.find(el => el.id === selectedElement)?.opacity || 100}
                    onChange={(e) => updateElement(selectedElement, { opacity: Number(e.target.value) })}
                    className="w-12 h-8 text-xs"
                    placeholder="100"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Fourth Row - Canvas & Background Controls */}
          <div className="flex items-center gap-4">
            {/* Canvas Size Controls */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-700">Canvas:</span>
              <label className="text-sm font-medium">Size:</label>
              <Input
                type="number"
                value={canvasWidth}
                onChange={(e) => setCanvasWidth(Number(e.target.value))}
                className="w-20 h-8 text-sm"
                placeholder="W"
              />
              <span className="text-sm">×</span>
              <Input
                type="number"
                value={canvasHeight}
                onChange={(e) => setCanvasHeight(Number(e.target.value))}
                className="w-20 h-8 text-sm"
                placeholder="H"
              />
              <Button
                size="default"
                variant="outline"
                onClick={() => {
                  setCanvasWidth(794); // A4 width in pixels at 96 DPI
                  setCanvasHeight(1123); // A4 height in pixels at 96 DPI
                }}
                className="h-8 px-3 text-sm"
                title="Set to A4 size"
              >
                A4
              </Button>
            </div>
            
            <div className="w-px h-8 bg-gray-300" />
            
            {/* Background Controls */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-700">Background:</span>
              <label className="text-sm font-medium">Image:</label>
              <Input
                type="file"
                accept="image/*"
                onChange={handleBackgroundUpload}
                className="text-sm h-8 w-24"
              />
              {background && (
                <>
                  <label className="text-sm font-medium">Blur:</label>
                  <Input
                    type="number"
                    min="0"
                    max="10"
                    value={blurAmount}
                    onChange={(e) => setBlurAmount(Number(e.target.value))}
                    className="w-16 h-8 text-sm"
                    placeholder="0"
                  />
                  <Button
                    size="default"
                    variant="outline"
                    onClick={() => setBackground('')}
                    className="h-8 px-3 text-sm"
                    title="Clear Background"
                  >
                    Clear
                  </Button>
                </>
              )}
            </div>
            
            <div className="w-px h-8 bg-gray-300" />
            
            {/* Save/Cancel Buttons */}
            <div className="flex items-center gap-2 ml-auto">
              <Button
                variant="outline"
                onClick={onCancel}
                className="h-9 px-4 text-sm"
              >
                Cancel
              </Button>
              <Button
                onClick={() => onSave(elements, background, blurAmount)}
                className="h-9 px-4 text-sm"
              >
                Save
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-auto relative bg-gray-100 pt-40 overflow-visible min-h-screen">
        <div
          ref={canvasRef}
          className="absolute bg-white shadow-lg rounded-lg overflow-hidden canvas-container"
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            width: `${canvasWidth}px`,
            height: `${canvasHeight}px`,
            border: canvasBorderWidth > 0 ? `${canvasBorderWidth}px solid ${canvasBorderColor}` : 'none'
          }}
          onClick={handleCanvasClick}
        >
          {/* Background layer with blur effect */}
          {background && (
            <div
              className="absolute inset-0"
              style={{
                backgroundImage: `url(${background})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                filter: `blur(${blurAmount}px)`,
                zIndex: 0
              }}
            />
          )}
          {elements.map((element) => (
            <div
              key={`${element.id}-${element.zIndex}`}
              className={`absolute border-2 ${
                selectedElement === element.id
                  ? 'border-blue-500'
                  : 'border-transparent hover:border-gray-300'
              } ${element.locked ? 'opacity-50' : ''}`}
              style={{
                left: `${element.x}px`,
                top: `${element.y}px`,
                width: `${element.width}px`,
                height: `${element.height}px`,
                zIndex: element.zIndex || 0, // Use zIndex directly without +1
                cursor: element.locked ? 'not-allowed' : 'move',
                opacity: element.visible ? (element.opacity / 100) : 0,
                // Remove border and borderRadius from container - will be applied to shapes individually
                boxShadow: element.frameType === 'shadow' ? '0 4px 8px rgba(0,0,0,0.1)' : undefined
              }}
              onClick={(e) => {
                e.stopPropagation();
                selectElement(element.id);
              }}
            >
              {/* Drag Handle Layer - Invisible but clickable */}
              <div
                className="absolute inset-0"
                style={{ zIndex: 10 }}
                onMouseDown={(e) => {
                  if (!element.locked) {
                    e.stopPropagation();
                    e.preventDefault();
                    handleMouseDown(e, element.id);
                  }
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  selectElement(element.id);
                }}
              />

              {element.type === 'text' && (
                <div
                  contentEditable={selectedElement === element.id}
                  suppressContentEditableWarning
                  className="w-full h-full p-2 outline-none cursor-text relative z-20"
                  style={{
                    color: element.color,
                    fontSize: `${element.fontSize}px`,
                    fontFamily: element.fontFamily,
                    fontWeight: element.fontWeight,
                    fontStyle: element.fontStyle,
                    textDecoration: element.textDecoration,
                    textAlign: element.textAlign as any,
                    listStyle: element.listStyle as any,
                    letterSpacing: `${element.letterSpacing}px`,
                    lineHeight: element.lineHeight,
                    backgroundColor: element.backgroundColor || 'transparent',
                    border: element.borderColor ? `${element.borderWidth || 1}px solid ${element.borderColor}` : 'none',
                    borderRadius: `${element.borderRadius || 0}px`,
                    // Remove flex display for text editing to allow proper line breaks
                    pointerEvents: selectedElement === element.id ? 'auto' : 'none',
                    userSelect: selectedElement === element.id ? 'text' : 'none',
                    whiteSpace: 'pre-wrap',
                    overflowWrap: 'break-word'
                  }}
                  onBlur={(e) => {
                    updateElement(element.id, { text: e.currentTarget.textContent || '' });
                  }}
                  onClick={(e) => {
                    e.stopPropagation();
                    // Allow text selection when clicking inside text
                  }}
                  onSelect={(e) => {
                    e.stopPropagation();
                    // Allow text selection
                  }}
                  onKeyDown={(e) => {
                    // Allow Enter key to work normally for new lines
                    if (e.key === 'Enter') {
                      // Don't prevent default - let it create a new line
                      return;
                    }
                    // Prevent other keyboard shortcuts from interfering
                    if (e.ctrlKey || e.metaKey) {
                      e.stopPropagation();
                    }
                  }}
                >
                  {element.listStyle === 'disc' ? (
                    <ul style={{ margin: 0, paddingLeft: '20px', listStyle: 'disc', textAlign: element.textAlign }}>
                      {element.text?.split('\n').filter(line => line.trim()).map((line, index) => (
                        <li key={index} style={{ marginBottom: '4px' }}>{line || '​'}</li>
                      ))}
                    </ul>
                  ) : element.listStyle === 'decimal' ? (
                    <ol style={{ margin: 0, paddingLeft: '20px', listStyle: 'decimal', textAlign: element.textAlign }}>
                      {element.text?.split('\n').filter(line => line.trim()).map((line, index) => (
                        <li key={index} style={{ marginBottom: '4px' }}>{line || '​'}</li>
                      ))}
                    </ol>
                  ) : (
                    <div style={{ textAlign: element.textAlign, whiteSpace: 'pre-wrap' }}>
                      {element.text}
                    </div>
                  )}
                </div>
              )}
              {element.type === 'rectangle' && (
                <div 
                  className="w-full h-full"
                  style={{
                    backgroundColor: element.backgroundColor || '#3b82f6',
                    border: element.borderColor ? `${element.borderWidth || 1}px solid ${element.borderColor}` : 'none',
                    borderRadius: `${element.borderRadius || 0}px`,
                    opacity: (element.opacity || 100) / 100
                  }}
                />
              )}
              {element.type === 'circle' && (
                <div 
                  className="w-full h-full rounded-full"
                  style={{
                    backgroundColor: element.backgroundColor || '#3b82f6',
                    border: element.borderColor ? `${element.borderWidth || 1}px solid ${element.borderColor}` : 'none',
                    opacity: (element.opacity || 100) / 100
                  }}
                />
              )}
              {element.type === 'triangle' && (
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <polygon 
                    points="50,10 90,90 10,90" 
                    fill={element.backgroundColor || '#3b82f6'}
                    stroke={element.borderColor || '#000000'}
                    strokeWidth={element.borderWidth || 0}
                    opacity={(element.opacity || 100) / 100}
                  />
                </svg>
              )}
              {element.type === 'hexagon' && (
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <polygon 
                    points="50,5 90,25 90,75 50,95 10,75 10,25" 
                    fill={element.backgroundColor || '#3b82f6'}
                    stroke={element.borderColor || '#000000'}
                    strokeWidth={element.borderWidth || 0}
                    opacity={(element.opacity || 100) / 100}
                  />
                </svg>
              )}
              {element.type === 'star' && (
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <polygon 
                    points="50,10 61,35 88,35 67,52 78,78 50,60 22,78 33,52 12,35 39,35" 
                    fill={element.backgroundColor || '#3b82f6'}
                    stroke={element.borderColor || '#000000'}
                    strokeWidth={element.borderWidth || 0}
                    opacity={(element.opacity || 100) / 100}
                  />
                </svg>
              )}
              {element.type === 'image' && element.image && (
                <>
                  <div
                    className="absolute inset-0"
                    style={{
                      backgroundImage: `url(${element.image})`,
                      backgroundSize: 'cover',
                      backgroundPosition: 'center',
                      opacity: (element.opacity || 100) / 100,
                      zIndex: 0 // Keep image at base level
                    }}
                  />
                  {/* Border overlay for image */}
                  {element.borderColor && element.borderWidth > 0 && (
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{
                        border: `${element.borderWidth}px solid ${element.borderColor}`,
                        borderRadius: `${element.borderRadius || 0}px`,
                        zIndex: 5 // Keep border overlay at consistent level
                      }}
                    />
                  )}
                  <div
                    className="absolute inset-0 border-2 border-dashed border-gray-400"
                    style={{
                      pointerEvents: element.locked ? 'none' : 'auto',
                      zIndex: 10 // Keep selection handle at consistent level
                    }}
                    onClick={(e) => {
                      if (!element.locked) {
                        e.stopPropagation();
                        selectElement(element.id);
                      }
                    }}
                  />
                </>
              )}
              
              {/* Background Image Layer */}
              {element.type === 'background' && (
                <div
                  className="absolute inset-0"
                  style={{
                    backgroundImage: `url(${element.image})`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    opacity: (element.opacity || 100) / 100,
                    zIndex: -1 // Keep background at lowest level
                  }}
                  onClick={(e) => {
                    if (!element.locked) {
                      e.stopPropagation();
                      selectElement(element.id);
                    }
                  }}
                />
              )}
              
              {/* Resize Handles - Only show when element is selected */}
              {selectedElement === element.id && !element.locked && (
                <>
                  {/* Corner handle for full resize */}
                  <div
                    className="absolute -bottom-2 -right-2 w-4 h-4 bg-blue-500 rounded-full cursor-se-resize"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startResize(e, element.id, 'se');
                    }}
                  />
                  
                  {/* Width handle */}
                  <div
                    className="absolute -right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 bg-blue-500 rounded-full cursor-e-resize"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startResize(e, element.id, 'e');
                    }}
                  />
                  
                  {/* Height handle */}
                  <div
                    className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-500 rounded-full cursor-s-resize"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startResize(e, element.id, 's');
                    }}
                  />
                  
                  {/* Left width handle */}
                  <div
                    className="absolute -left-2 top-1/2 transform -translate-y-1/2 w-4 h-4 bg-blue-500 rounded-full cursor-w-resize"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startResize(e, element.id, 'w');
                    }}
                  />
                  
                  {/* Top height handle */}
                  <div
                    className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-500 rounded-full cursor-n-resize"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startResize(e, element.id, 'n');
                    }}
                  />
                  
                  {/* Top-left corner handle */}
                  <div
                    className="absolute -top-2 -left-2 w-4 h-4 bg-blue-500 rounded-full cursor-nw-resize"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startResize(e, element.id, 'nw');
                    }}
                  />
                  
                  {/* Top-right corner handle */}
                  <div
                    className="absolute -top-2 -right-2 w-4 h-4 bg-blue-500 rounded-full cursor-ne-resize"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startResize(e, element.id, 'ne');
                    }}
                  />
                  
                  {/* Bottom-left corner handle */}
                  <div
                    className="absolute -bottom-2 -left-2 w-4 h-4 bg-blue-500 rounded-full cursor-sw-resize"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startResize(e, element.id, 'sw');
                    }}
                  />
                </>
              )}
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}