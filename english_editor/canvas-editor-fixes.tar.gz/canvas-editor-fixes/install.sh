#!/bin/bash

# Canvas Editor Fixes - Installation Script
# این اسکریپ فایل‌های اصلاح شده را در پروژه شما کپی می‌کند

echo "🎨 Canvas Editor Fixes - Installation Script"
echo "=========================================="

# Check if we're in the right directory
if [ ! -d "src" ]; then
    echo "❌ Error: Please run this script from the root of your Next.js project"
    echo "   The script expects to find a 'src' directory"
    exit 1
fi

# Create backup of original files
echo "📦 Creating backup of original files..."
mkdir -p backup

if [ -f "src/components/canvas-editor/AdvancedCanvasEditor.tsx" ]; then
    cp src/components/canvas-editor/AdvancedCanvasEditor.tsx backup/
fi

if [ -f "src/components/canvas-editor/SimplePostEditor.tsx" ]; then
    cp src/components/canvas-editor/SimplePostEditor.tsx backup/
fi

if [ -f "src/app/api/posts/route.ts" ]; then
    cp src/app/api/posts/route.ts backup/
fi

if [ -f "src/app/page.tsx" ]; then
    cp src/app/page.tsx backup/
fi

echo "✅ Backup created in 'backup' directory"

# Copy fixed files
echo "📋 Copying fixed files..."

# Ensure directories exist
mkdir -p src/components/canvas-editor
mkdir -p src/app/api/posts

# Copy the files
cp AdvancedCanvasEditor.tsx src/components/canvas-editor/
cp SimplePostEditor.tsx src/components/canvas-editor/
cp route.ts src/app/api/posts/
cp page.tsx src/app/

echo "✅ Files copied successfully!"

# Check if dependencies are installed
echo "🔍 Checking dependencies..."

if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
else
    echo "✅ Dependencies already installed"
fi

echo ""
echo "🎉 Installation completed successfully!"
echo ""
echo "📝 What was fixed:"
echo "   • Layer management with proper swapping"
echo "   • Background color for text boxes"
echo "   • Border controls for shapes"
echo "   • A4 canvas size (794×1123px)"
echo "   • Fixed 500 error (unique slug issue)"
echo "   • Large modal (80vh instead of 600px)"
echo "   • User view for published posts"
echo "   • Debug functionality"
echo ""
echo "🚀 To start the development server:"
echo "   npm run dev"
echo ""
echo "🐛 For debugging:"
echo "   • Use the Debug button in layer controls"
echo "   • Check browser console for detailed logs"
echo "   • Use 'Create Test Post' button in user tab"
echo ""
echo "📁 Backup files are in 'backup' directory"
echo "📖 Read README.md for detailed information"